<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class funcion extends Model
{
    //
}
