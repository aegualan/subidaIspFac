@extends('layouts.app')

@section('content')
<!-- Main content -->
<section class="content">

colores
    <!-- /.box -->
</section>
<!-- /.content -->
@endsection
