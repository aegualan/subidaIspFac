

<html>
    <head>

        <title>
            pdf
        </title>
        
<style>
.page-break {
    page-break-after: always;
}
</style>
         <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet"/>
    </head>
    <body>
        <!--        <div style="margin-left: 5px; margin-right: 5px; margin-top: 5px">-->
        <table style="width: 100%">
            <tr>
                <td style="width: 50%">
                    <table style="width: 100%">
                        <tr>
                            <td style="text-align: center; width: 100%"><img src="assets/img/logo.png" style="height: 100px"></td>
                        </tr>
                        <tr>
                            <td style="width: 100%">
                                <div style="border: 1px solid black; border-radius: 10px; width: 100%">
                                    <h6 style="text-align: center">TELCOMPSYSTEMS. CIA. LTDA.</h6>
                                    <p style="text-align: justify"><strong>Direccion Matriz:</strong> PUENTE EL CABALLITO - CHILLOGAL Calle: OE7CCCNumero: S31-
                                        140 Interseccion: MANUEL CHERREZ</p>
                                </div>
                            </td>
                        </tr>
                    </table>
                </td>
                <td style="width: 50%">
                    <div style="border: 1px solid black; border-radius: 10px; width: 100%">
                        <p style="text-align: justify"><strong>R.U.C.: </strong>1792905028001</p>
                        <p style="text-align: justify"><strong>COMPROBANTE</strong> Nro. 000-000-000000001</p>
                        <p style="text-align: justify"><strong>FECHA DE EMISION</strong> 22/23/56</p>
                        <p style="text-align: justify"><strong>FECHA MAXIMO DE PAGO</strong> </br>Nro. 000-000-000000001</p>
                    </div>
                </td>
            </tr>
        </table>
        <!--        </div>-->
        <br/>
        <div style="border: 1px solid black; width: 100%">
            <table style="width: 100%">
                <tr>
                    <td style="width: 10%"><strong>Cliente:</strong></td>
                    <td style="width: 50%" style="text-align: justify">CHOLOQUINGA CHOLOQUINGA SEGUNDO ANTONIO hhhhhhhhhhhhhhhhhh</td>
                    <td style="width: 10%"><strong>Identificación:</strong></td>
                    <td style="width: 10%">0502733595</td>
                </tr>
                <tr>
                    <td><strong>Dirección</strong></td>
                    <td colspan="4" style="text-align: justify">ggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg</td>
                </tr>
            </table>
        </div>
        <br/>
        <table class="table table-bordered table-condensed">
            <thead>
                <tr>
                    <th>Cant.</th>
                    <th>Descripción</th>
                    <th>Val. Unitario</th>
                    <th>Descuento</th>
                    <th>Val. Total </th>
                </tr>
            </thead>
        </table>
        Hello, <?php echo e($name); ?>.
    </body>
</html>
