<input id="token" name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>"/>
<div class="form-group">
    <label class="col-sm-2 control-label colorLabel" for="codPersona">
        Cédula/Ruc:
    </label>
    <div class="col-sm-10">
        <input class="form-control altoTxt" id="codPersona" maxlength="13" onkeyup="return identidad('codPersona');" type="text">
            <span class="help-block">
            </span>
        </input>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label colorLabel" for="apePersona">
        Apellidos:
    </label>
    <div class="col-sm-10">
        <input class="form-control altoTxt" id="apePersona" onkeyup="ConvertirMayusculas('apePersona'); return obligatorio('apePersona');" type="text">
            <span class="help-block">
            </span>
        </input>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label colorLabel" for="nomPersona">
        Nombres:
    </label>
    <div class="col-sm-10">
        <input class="form-control altoTxt" id="nomPersona" onkeyup="ConvertirMayusculas('nomPersona'); return obligatorio('nomPersona');" type="text">
            <span class="help-block">
            </span>
        </input>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label colorLabel" for="telPersona">
        Teléfono:
    </label>
    <div class="col-sm-10">
        <input class="form-control altoTxt" id="telPersona" onkeyup="return soloNumeros('telPersona')" type="text">
            <span class="help-block">
            </span>
        </input>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label colorLabel" for="celPersona">
        Celular:
    </label>
    <div class="col-sm-10">
        <input class="form-control altoTxt" id="celPersona" onkeyup="return soloNumeros('celPersona')" type="text">
            <span class="help-block">
            </span>
        </input>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label colorLabel" for="emaPersona">
        Email:
    </label>
    <div class="col-sm-10">
        <input class="form-control altoTxt" id="emaPersona" onkeyup="return email('emaPersona');" type="text">
            <span class="help-block">
            </span>
        </input>
    </div>
</div>
