<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sectorial extends Model
{
    //
}
