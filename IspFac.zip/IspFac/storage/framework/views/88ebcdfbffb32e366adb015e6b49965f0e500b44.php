<tr>
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
            <tr>
                <td class="content-cell" align="center">
                    <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

                </td>
            </tr>
        </table>
    </td>
</tr>
