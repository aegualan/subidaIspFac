<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
    <h4 class="box-title text-center">
        <?php echo e(Utilitarios::titulo()); ?>

    </h4>
    <table class="display responsive table table-bordered table-bordered mGrid" id="tblFacPag" style="width:100%">
        <thead>
            <tr>
                <th>
                    Nro. Contrato
                </th>
                <th>
                    Cédula/Ruc
                </th>
                <th>
                    Cliente
                </th>
                <th>
                    Nro. Comprobante
                </th>
                <th>
                    Fecha Pagado
                </th>
                <th>
                    Mes Servicio
                </th>
                <th>
                    Plan
                </th>
                <th>
                    Precio
                </th>
            </tr>
        </thead>
        <!--                <tbody id='tblDatos'></tbody>-->
    </table>
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    var tblFacPag = $('#tblFacPag').DataTable({
            "processing": true,
            "serverSide": true,
            "ajax": "/facturas-cobradas/create",
            "searching": true,
            "paging": true,
            "ordering": false,
            "info":     false,
            "columns": [
                {data: "codContrato","width": "10%"},
                {data: "codPersona","width": "10%"},
                {data: "nomCompletoPersona","width": "30%"},
                {data: "numComprobante","width": "8%"},
                {data: "fecPago","searchable": false,"width": "8%"},
       
                {data: "mesServicio","searchable": false,"width": "10%"},
                {data: "nomPlan","searchable": false,"width": "10%"},
                {data: "prePlan","searchable": false,"width": "5%"},
            ],
        

        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>